package com.example.ASSIGNMENT;

public class PersonController {
    @MyAutowired
    AnimalController animalController;

    public boolean isPetSet(){
        return AnimalController != null;
    }
}
