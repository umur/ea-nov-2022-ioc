package com.example.ASSIGNMENT;
@MyBean
public class AnimalController {


}
